export const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  try {
    const d = new Date(dateString);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  } catch (e) {
    return dateString;
  }
};

export const getPotentialBadgeColor = (level) => {
  switch (level?.toUpperCase()) {
    case 'HIGH':
      return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
    case 'MEDIUM':
      return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
    case 'DEVELOPING':
      return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
    default:
      return 'bg-slate-500/10 text-slate-400 border-slate-500/30';
  }
};

export const getPerformanceStatusBadgeColor = (status) => {
  switch (status?.toUpperCase()) {
    case 'AI ANALYZED':
      return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
    case 'EVALUATED':
      return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
    case 'NOT EVALUATED':
    default:
      return 'bg-slate-500/10 text-slate-400 border-slate-500/30';
  }
};

export const getRoleBadgeColor = (role) => {
  switch (role?.toUpperCase()) {
    case 'PLAYER':
      return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
    case 'COACH':
      return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
    case 'SCOUT':
      return 'bg-purple-500/10 text-purple-400 border-purple-500/30';
    case 'ADMIN':
      return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
    default:
      return 'bg-slate-500/10 text-slate-400 border-slate-500/30';
  }
};

export const getScoreColor = (score) => {
  if (score >= 85) return 'text-emerald-400';
  if (score >= 70) return 'text-cyan-400';
  if (score >= 55) return 'text-amber-400';
  return 'text-rose-400';
};

export const getConfidenceColor = (score) => {
  if (score >= 85) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
  if (score >= 70) return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
  if (score >= 50) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
  return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
};

export const getSourceTypeDetails = (sourceType) => {
  switch (sourceType?.toUpperCase()) {
    case 'STANDARDIZED_FIELD_TEST':
      return {
        label: 'Field Test Protocol',
        icon: '⏱️',
        badgeColor: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
      };
    case 'SMARTPHONE_DERIVED':
      return {
        label: 'Smartphone Sensor',
        icon: '📱',
        badgeColor: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
      };
    case 'COACH_VERIFIED':
      return {
        label: 'Coach Certified Trial',
        icon: '📋',
        badgeColor: 'bg-purple-500/10 text-purple-300 border-purple-500/30'
      };
    case 'WEARABLE_DEVICE':
      return {
        label: 'Wearable Sensor',
        icon: '⌚',
        badgeColor: 'bg-blue-500/10 text-blue-300 border-blue-500/30'
      };
    case 'SELF_REPORTED_MANUAL':
    default:
      return {
        label: 'Self-Reported Entry',
        icon: '✍️',
        badgeColor: 'bg-amber-500/10 text-amber-300 border-amber-500/30'
      };
  }
};

export const getVerificationStatusDetails = (status) => {
  switch (status?.toUpperCase()) {
    case 'COACH_VERIFIED':
      return {
        label: 'Coach Certified',
        badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
        isVerified: true
      };
    case 'AI_VIDEO_VERIFIED':
      return {
        label: 'Video AI Verified',
        badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
        isVerified: true
      };
    case 'SYSTEM_VALIDATED':
      return {
        label: 'System Validated',
        badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
        isVerified: true
      };
    case 'UNVERIFIED':
    default:
      return {
        label: 'Unverified Entry',
        badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
        isVerified: false
      };
  }
};

export const getImageUrl = (path) => {
  if (!path) return null;
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:')) {
    return path;
  }
  const backendBase = import.meta.env.VITE_SERVER_URL || 'http://127.0.0.1:8000';
  return `${backendBase}${path.startsWith('/') ? '' : '/'}${path}`;
};
