import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { adminService } from '../../services/adminService';
import {
  Users,
  Trophy,
  Activity,
  ShieldCheck,
  Calendar,
  Building,
  ArrowRight,
  Clock,
  CheckCircle2,
  XCircle,
  Plus,
  Eye,
  UserCheck,
  Search,
  Sparkles
} from 'lucide-react';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import Loader from '../../components/common/Loader';

export const AdminDashboard = () => {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        setLoading(true);
        const data = await adminService.getDashboard();
        setDashboard(data);
      } catch (e) {
        console.error('Failed to load admin dashboard:', e);
      } finally {
        setLoading(false);
      }
    };

    loadDashboard();
  }, []);

  if (loading) {
    return <Loader message="Loading platform administrative intelligence..." className="py-24" />;
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white font-display tracking-tight">Admin Dashboard</h1>
            <Badge variant="primary" className="bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 font-bold">
              Superuser Governance
            </Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage SportIQ users, organizers, events and platform activity.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Link to="/admin/events/verification">
            <Button variant="secondary" size="sm" icon={Clock} className="border-amber-500/30 text-amber-700 dark:text-amber-400">
              Verification Queue ({dashboard?.pending_events || 0})
            </Button>
          </Link>
          <Link to="/admin/events/new">
            <Button variant="primary" size="sm" icon={Plus}>+ Add Sports Event</Button>
          </Link>
        </div>
      </div>

      {/* User Demographics KPIs */}
      <div>
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
          User & Roster Demographics
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
          <Link to="/admin/users">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Total Users</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-display">
                  {dashboard?.total_users || 0}
                </span>
                <span className="text-[11px] text-slate-400">Accounts</span>
              </div>
            </Card>
          </Link>

          <Link to="/admin/athletes">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 block mb-1">Total Athletes</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-display">
                  {dashboard?.total_athletes || 0}
                </span>
                <span className="text-[11px] text-slate-400">Profiles</span>
              </div>
            </Card>
          </Link>

          <Link to="/admin/coaches">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-cyan-600 dark:text-cyan-400 block mb-1">Total Coaches</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-cyan-600 dark:text-cyan-400 font-display">
                  {dashboard?.total_coaches || 0}
                </span>
                <span className="text-[11px] text-slate-400">Trainers</span>
              </div>
            </Card>
          </Link>

          <Link to="/admin/scouts">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-purple-600 dark:text-purple-400 block mb-1">Total Scouts</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-purple-600 dark:text-purple-400 font-display">
                  {dashboard?.total_scouts || 0}
                </span>
                <span className="text-[11px] text-slate-400">Recruiters</span>
              </div>
            </Card>
          </Link>

          <Link to="/admin/organizers">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400 block mb-1">Total Organizers</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-display">
                  {dashboard?.total_organizers || 0}
                </span>
                <span className="text-[11px] text-slate-400">Hosts</span>
              </div>
            </Card>
          </Link>
        </div>
      </div>

      {/* Sports Events Metrics */}
      <div>
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
          Sports Events & Verification KPIs
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
          <Link to="/admin/events">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1">Total Events</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-display">
                {dashboard?.total_events || 0}
              </span>
            </Card>
          </Link>

          <Link to="/admin/events">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 block mb-1">Published Events</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-display">
                {dashboard?.published_events || 0}
              </span>
            </Card>
          </Link>

          <Link to="/admin/events/verification">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400 block mb-1">Pending Events</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-display">
                {dashboard?.pending_events || 0}
              </span>
            </Card>
          </Link>

          <Link to="/admin/events">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 block mb-1">Rejected Events</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-rose-600 dark:text-rose-400 font-display">
                {dashboard?.rejected_events || 0}
              </span>
            </Card>
          </Link>

          <Link to="/events">
            <Card hover className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 p-4">
              <span className="text-[11px] font-semibold text-cyan-600 dark:text-cyan-400 block mb-1">Upcoming Events</span>
              <span className="text-2xl sm:text-3xl font-extrabold text-cyan-600 dark:text-cyan-400 font-display">
                {dashboard?.upcoming_events || 0}
              </span>
            </Card>
          </Link>
        </div>
      </div>

      {/* Activity Streams Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Event Submissions */}
        <Card title="Recent Event Submissions" icon={Calendar}>
          {dashboard?.recent_event_submissions?.length > 0 ? (
            <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {dashboard.recent_event_submissions.map(e => (
                <div key={e.id} className="py-3 flex items-center justify-between gap-3 first:pt-0 last:pb-0">
                  <div className="space-y-0.5 max-w-[65%]">
                    <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">{e.title}</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                      Organizer: <strong>{e.organizer_name}</strong> • Sport: {e.sport}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <Badge variant={e.status === 'PUBLISHED' ? 'primary' : e.status === 'PENDING_REVIEW' ? 'secondary' : 'default'} size="sm">
                      {e.status}
                    </Badge>
                    <Link to={`/admin/events/${e.id}/review`}>
                      <Button variant="primary" size="sm" className="text-xs bg-cyan-600 hover:bg-cyan-500 py-1 px-2.5">
                        [Review]
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 py-4 text-center">No recent event submissions.</p>
          )}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-right">
            <Link to="/admin/events/verification" className="text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:underline">
              View All Verification Queue →
            </Link>
          </div>
        </Card>

        {/* Recent User Registrations */}
        <Card title="Recent User Registrations" icon={Users}>
          {dashboard?.recent_users?.length > 0 ? (
            <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {dashboard.recent_users.map(u => (
                <div key={u.id} className="py-3 flex items-center justify-between gap-3 first:pt-0 last:pb-0">
                  <div className="space-y-0.5 max-w-[65%]">
                    <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">{u.name}</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
                      {u.email || u.phone_number} • Joined {new Date(u.created_at).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <Badge variant="primary" size="sm">
                      {u.role}
                    </Badge>
                    <Link to="/admin/users">
                      <Button variant="secondary" size="sm" className="text-xs py-1 px-2">
                        View
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 py-4 text-center">No recent registrations.</p>
          )}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-right">
            <Link to="/admin/users" className="text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:underline">
              Manage All Users →
            </Link>
          </div>
        </Card>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <Link to="/admin/athletes" className="block group">
          <Card hover className="h-full border-t-2 border-t-emerald-500 p-4">
            <div className="flex items-center justify-between mb-1.5">
              <h3 className="font-bold text-slate-900 dark:text-white font-display text-xs sm:text-sm">Athlete Management</h3>
              <ArrowRight className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Inspect athlete profiles, registered sports, and account statuses.
            </p>
          </Card>
        </Link>

        <Link to="/admin/coaches" className="block group">
          <Card hover className="h-full border-t-2 border-t-cyan-500 p-4">
            <div className="flex items-center justify-between mb-1.5">
              <h3 className="font-bold text-slate-900 dark:text-white font-display text-xs sm:text-sm">Coach Management</h3>
              <ArrowRight className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Oversee coach credentials, squad allocations, and recommendations.
            </p>
          </Card>
        </Link>

        <Link to="/admin/organizers" className="block group">
          <Card hover className="h-full border-t-2 border-t-amber-500 p-4">
            <div className="flex items-center justify-between mb-1.5">
              <h3 className="font-bold text-slate-900 dark:text-white font-display text-xs sm:text-sm">Organizer Accreditation</h3>
              <ArrowRight className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Verify sports academies, district bodies, and tournament organizations.
            </p>
          </Card>
        </Link>

        <Link to="/admin/reports" className="block group">
          <Card hover className="h-full border-t-2 border-t-purple-500 p-4">
            <div className="flex items-center justify-between mb-1.5">
              <h3 className="font-bold text-slate-900 dark:text-white font-display text-xs sm:text-sm">Platform Reports</h3>
              <ArrowRight className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Generate PostgreSQL analytics, user growth rates, and event logs.
            </p>
          </Card>
        </Link>
      </div>
    </div>
  );
};

export default AdminDashboard;
