import React, { useState, useEffect } from 'react';
import { playerService } from '../../services/playerService';
import { performanceService } from '../../services/performanceService';
import { aiService } from '../../services/aiService';
import {
  BrainCircuit,
  Zap,
  ShieldAlert,
  CheckCircle2,
  Lightbulb,
  TrendingUp,
  History,
  ShieldCheck,
  Smartphone,
  Award
} from 'lucide-react';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Loader from '../../components/common/Loader';
import EmptyState from '../../components/common/EmptyState';
import TalentRadarChart from '../../components/charts/TalentRadarChart';
import { getPotentialBadgeColor, getScoreColor, getConfidenceColor, formatDate } from '../../utils/formatters';

export const AIAnalysisPage = () => {
  const [profile, setProfile] = useState(null);
  const [latestAI, setLatestAI] = useState(null);
  const [historyAI, setHistoryAI] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAI = async () => {
      try {
        setLoading(true);
        const prof = await playerService.getMyProfile();
        setProfile(prof);

        if (prof?.id) {
          const [aiData, aiHist, statsData] = await Promise.all([
            aiService.getLatestPlayerAI(prof.id).catch(() => null),
            aiService.getPlayerAIHistory(prof.id).catch(() => []),
            performanceService.getPlayerStats(prof.id).catch(() => null)
          ]);
          setLatestAI(aiData);
          setHistoryAI(aiHist);
          setStats(statsData);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };

    loadAI();
  }, []);

  if (loading) {
    return <Loader message="Running AI talent neural analysis..." className="py-24" />;
  }

  if (!latestAI) {
    return (
      <div className="max-w-xl mx-auto py-12">
        <EmptyState
          icon={BrainCircuit}
          title="No AI Analysis Available"
          description="Log at least one performance session in the Performance section to generate your comprehensive AI talent projection."
        />
      </div>
    );
  }

  const dataConf = latestAI.data_confidence_score || (stats?.avg_data_confidence_score || 70.0);

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-200 dark:border-slate-800/80">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white font-display tracking-tight">AI Talent Intelligence</h1>
          <Badge variant="primary" size="sm">Model {latestAI.model_version || 'v1.0'}</Badge>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">Position-weighted neural evaluation, transparent evidence confidence, and developmental insights</p>
      </div>

      {/* Device-Inclusive Equity Banner */}
      <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-gradient-to-r dark:from-cyan-950/40 dark:to-slate-900 border border-slate-200 dark:border-cyan-500/20 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <Award className="w-5 h-5 text-cyan-600 dark:text-cyan-400 shrink-0" />
          <span className="text-slate-700 dark:text-slate-300">
            <strong className="text-slate-900 dark:text-white">Device-Inclusive & Equitable Scoring:</strong> Talent Index measures pure athletic capability across field tests, smartphone measurements, and video proof without requiring expensive wearable devices.
          </span>
        </div>
        <span className="shrink-0 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 text-[11px] font-semibold">
          Equal Opportunity Standard
        </span>
      </div>

      {/* Dual Score Banners */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white dark:bg-gradient-to-br dark:from-cyan-950/40 dark:via-slate-900 dark:to-slate-900 border-slate-200 dark:border-cyan-500/30 md:col-span-1 flex flex-col justify-between space-y-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400 block mb-2">Projected AI Talent Index</span>
            <div className="flex items-baseline gap-2 mb-3">
              <span className={`text-5xl font-extrabold font-display ${getScoreColor(latestAI.talent_score)}`}>
                {Math.round(latestAI.talent_score)}
              </span>
              <span className="text-sm text-slate-400 dark:text-slate-500">/ 100</span>
            </div>
            <Badge variant="primary" size="lg" className={getPotentialBadgeColor(latestAI.potential_level)}>
              {latestAI.potential_level} Potential
            </Badge>
          </div>

          {/* Data Confidence Indicator */}
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-bold uppercase text-[10px]">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" /> Evidence Confidence
              </span>
              <span className={`font-bold px-2 py-0.5 rounded-full border text-xs ${getConfidenceColor(dataConf)}`}>
                {dataConf.toFixed(0)}%
              </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400"
                style={{ width: `${Math.min(Math.max(dataConf, 10), 100)}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 block">
              Confidence score reflects proof quality, protocol consistency, and coach attestations.
            </span>
          </div>
        </Card>

        {/* Radar */}
        <Card title="5-Pillar Position Radar" subtitle="Calculated based on your specific playing role" className="md:col-span-2">
          <TalentRadarChart
            speed={stats?.avg_speed || 70}
            stamina={stats?.avg_stamina || 70}
            strength={stats?.avg_strength || 70}
            agility={stats?.avg_agility || 70}
            accuracy={stats?.avg_accuracy || 70}
            height={260}
          />
        </Card>
      </div>

      {/* Strengths & Weaknesses Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Strengths */}
        <Card title="Identified Core Strengths" icon={CheckCircle2}>
          <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-500/30">
            <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block mb-2">Competitive Advantages</span>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-2">{latestAI.strengths}</p>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              These metrics exceed target percentiles for {profile?.sport} ({profile?.position}). Continue leveraging these attributes in competitive fixtures.
            </p>
          </div>
        </Card>

        {/* Weaknesses */}
        <Card title="Targeted Areas for Improvement" icon={ShieldAlert}>
          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-500/30">
            <span className="text-xs font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider block mb-2">Growth Bottlenecks</span>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-2">{latestAI.weaknesses}</p>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Targeting these specific metrics will directly elevate your overall talent score and matchday impact.
            </p>
          </div>
        </Card>
      </div>

      {/* Automated Training Recommendations */}
      <Card title="Automated AI Development Protocol" icon={Lightbulb}>
        <div className="p-5 rounded-xl bg-cyan-50 dark:bg-cyan-950/20 border border-cyan-200 dark:border-cyan-500/30">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-700 dark:text-cyan-400 block mb-2">Prescribed Workout Routine</span>
          <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">{latestAI.recommendations}</p>
        </div>
      </Card>

      {/* History Timeline */}
      {historyAI.length > 1 && (
        <Card title="AI Evaluation Timeline" icon={History} subtitle="Evolution of talent scores across assessment cycles">
          <div className="space-y-2">
            {historyAI.map((item, idx) => (
              <div key={item.id || idx} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400 dark:text-slate-500 font-mono">#{historyAI.length - idx}</span>
                  <span className="text-xs text-slate-700 dark:text-slate-300 font-semibold">{formatDate(item.created_at)}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-slate-500 dark:text-slate-400">Score: <strong className="text-slate-900 dark:text-white">{item.talent_score}</strong></span>
                  <Badge variant="primary" size="sm" className={getPotentialBadgeColor(item.potential_level)}>
                    {item.potential_level}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};
export default AIAnalysisPage;
