import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { eventService } from '../../services/eventService';
import {
  Calendar,
  MapPin,
  Search,
  Filter,
  ShieldCheck,
  Trophy,
  Bookmark,
  BookmarkCheck,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Clock,
  User,
  Users,
  Compass,
  AlertCircle,
  Plus
} from 'lucide-react';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import Loader from '../../components/common/Loader';
import { DEFAULT_SPORTS, EVENT_TYPES, COMPETITION_LEVELS, INDIAN_STATES } from '../../utils/constants';

export const EventHubPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [events, setEvents] = useState([]);
  const [totalEvents, setTotalEvents] = useState(0);
  const [loading, setLoading] = useState(true);

  // Active Discovery Tab: 'upcoming', 'near_me', 'recommended', 'saved'
  const [activeTab, setActiveTab] = useState('upcoming');

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSport, setSelectedSport] = useState('');
  const [selectedEventType, setSelectedEventType] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedGender, setSelectedGender] = useState('');

  // Bookmarking Action State
  const [bookmarkingId, setBookmarkingId] = useState(null);

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const params = {
        tab: activeTab,
        page: 1,
        limit: 50
      };

      if (searchQuery.trim()) params.search = searchQuery.trim();
      if (selectedSport) params.sport = selectedSport;
      if (selectedEventType) params.event_type = selectedEventType;
      if (selectedLevel) params.competition_level = selectedLevel;
      if (selectedState) params.state = selectedState;
      if (selectedCity) params.city = selectedCity;
      if (selectedGender) params.gender = selectedGender;

      const data = await eventService.getEvents(params);
      if (data) {
        setEvents(data.events || []);
        setTotalEvents(data.total || 0);
      } else {
        setEvents([]);
        setTotalEvents(0);
      }
    } catch (err) {
      console.error('Failed to load events:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, [activeTab, selectedSport, selectedEventType, selectedLevel, selectedState, selectedCity, selectedGender]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchEvents();
  };

  const handleToggleBookmark = async (e, eventId, isSaved) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      navigate('/login');
      return;
    }

    setBookmarkingId(eventId);
    try {
      if (isSaved) {
        await eventService.unsaveEvent(eventId);
      } else {
        await eventService.saveEvent(eventId);
      }
      setEvents(prev => prev.map(ev => ev.id === eventId ? { ...ev, is_saved: !isSaved } : ev));
    } catch (err) {
      alert(err.message || 'Unable to update bookmark');
    } finally {
      setBookmarkingId(null);
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedSport('');
    setSelectedEventType('');
    setSelectedLevel('');
    setSelectedState('');
    setSelectedCity('');
    setSelectedGender('');
    setActiveTab('upcoming');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 text-white overflow-hidden shadow-lg border border-cyan-500/20">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-extrabold uppercase tracking-wider">
              Sports Opportunities
            </span>
            {user?.role === 'ORGANIZER' && (
              <Link to="/organizer/events/new">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1 hover:bg-emerald-500/30 transition-all">
                  <Plus className="w-3.5 h-3.5" /> + Host Event
                </span>
              </Link>
            )}
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold font-display tracking-tight uppercase">
            Sport<span className="text-cyan-400">IQ</span> Event Hub
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
            Discover upcoming tournaments, championships, trials and sports opportunities verified by official federations and academies.
          </p>
        </div>
      </div>

      {/* Discovery Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'upcoming'
                ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border border-cyan-500/40 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Upcoming Events</span>
          </button>

          <button
            onClick={() => setActiveTab('near_me')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'near_me'
                ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border border-cyan-500/40 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Near Me</span>
          </button>

          {user && (
            <>
              <button
                onClick={() => setActiveTab('recommended')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'recommended'
                    ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span>Recommended</span>
              </button>

              <button
                onClick={() => setActiveTab('saved')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'saved'
                    ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <Bookmark className="w-4 h-4 text-amber-500" />
                <span>Saved Events</span>
              </button>
            </>
          )}
        </div>

        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          Showing <strong>{events.length}</strong> of <strong>{totalEvents}</strong> events
        </span>
      </div>

      {/* Search & Multi-Filter Controls */}
      <Card className="p-4 sm:p-5 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search tournaments, championship titles, city, venue, or organizer..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
            />
          </div>
          <Button type="submit" variant="primary" size="md">
            Search
          </Button>
        </form>

        {/* Filter Dropdowns */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5 pt-1">
          {/* Sport Filter */}
          <div>
            <select
              value={selectedSport}
              onChange={(e) => setSelectedSport(e.target.value)}
              className="w-full p-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">All Sports</option>
              {DEFAULT_SPORTS.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {/* Event Type Filter */}
          <div>
            <select
              value={selectedEventType}
              onChange={(e) => setSelectedEventType(e.target.value)}
              className="w-full p-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">All Event Types</option>
              {EVENT_TYPES.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Level Filter */}
          <div>
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="w-full p-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">All Levels</option>
              {COMPETITION_LEVELS.map(l => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>

          {/* State Filter */}
          <div>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full p-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">All States</option>
              {INDIAN_STATES.map(st => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

          {/* City / Near Me Quick Selector */}
          <div>
            <input
              type="text"
              placeholder="Filter City (e.g. Coimbatore)"
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full p-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-cyan-500"
            />
          </div>

          {/* Clear Button */}
          <div>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={clearFilters}
              className="w-full text-xs"
            >
              Reset Filters
            </Button>
          </div>
        </div>
      </Card>

      {/* Events Grid / List */}
      {loading ? (
        <Loader message="Loading verified sports opportunities..." className="py-24" />
      ) : events.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          {events.map((event) => {
            const formattedDate = new Date(event.start_date).toLocaleDateString('en-US', {
              day: 'numeric',
              month: 'short',
              year: 'numeric'
            });
            const deadlineFormatted = new Date(event.registration_deadline).toLocaleDateString('en-US', {
              day: 'numeric',
              month: 'short',
              year: 'numeric'
            });

            return (
              <Card
                key={event.id}
                className="p-5 sm:p-6 bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 hover:border-cyan-500/50 shadow-sm transition-all duration-200 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Top Badges & Bookmark Star */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge variant="primary" size="sm" className="bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border-cyan-500/30">
                        {event.sport}
                      </Badge>
                      <Badge variant="secondary" size="sm">
                        {event.event_type}
                      </Badge>
                      <Badge variant="primary" size="sm" className="bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/30">
                        {event.competition_level}
                      </Badge>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => handleToggleBookmark(e, event.id, event.is_saved)}
                      disabled={bookmarkingId === event.id}
                      className={`p-2 rounded-xl border transition-all cursor-pointer ${
                        event.is_saved
                          ? 'bg-amber-500/15 border-amber-500/30 text-amber-500'
                          : 'border-slate-200 dark:border-slate-800 text-slate-400 hover:text-amber-500 hover:border-amber-500/40'
                      }`}
                      title={event.is_saved ? 'Remove Bookmark' : 'Save Event'}
                    >
                      <Bookmark className={`w-4 h-4 ${event.is_saved ? 'fill-amber-500' : ''}`} />
                    </button>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <Link to={`/events/${event.id}`}>
                      <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors font-display">
                        {event.title}
                      </h3>
                    </Link>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                      {event.description}
                    </p>
                  </div>

                  {/* Key Metadata Matrix */}
                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-300 pt-1 font-medium">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 shrink-0" />
                      <span>{formattedDate}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                      <span className="truncate">{event.city}, {event.state}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Eligibility: {event.age_min ? `${event.age_min}–${event.age_max || 'Any'} yrs` : 'All ages'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      <span>Deadline: {deadlineFormatted}</span>
                    </div>
                  </div>
                </div>

                {/* Footer Strip */}
                <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 text-xs font-bold">
                    <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
                    <span>🟢 Verified Event</span>
                  </div>

                  <Link to={`/events/${event.id}`}>
                    <Button variant="primary" size="sm" className="text-xs inline-flex items-center gap-1">
                      <span>View Details</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </Button>
                  </Link>
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="p-12 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">No verified sports events found</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
            Try adjusting your search query, sport discipline, or location filters.
          </p>
          <div className="pt-2">
            <Button variant="secondary" size="sm" onClick={clearFilters}>
              Reset All Filters
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default EventHubPage;
