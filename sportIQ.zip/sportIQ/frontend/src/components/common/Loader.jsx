import React from 'react';

export const Loader = ({ message = 'Loading...', size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4',
  };

  return (
    <div className={`flex flex-col items-center justify-center p-8 text-center ${className}`}>
      <div
        className={`${sizeClasses[size] || sizeClasses.md} rounded-full border-cyan-500/20 border-t-cyan-500 dark:border-t-cyan-400 animate-spin mb-3`}
      />
      {message && <p className="text-xs font-medium text-slate-600 dark:text-slate-400 tracking-wide">{message}</p>}
    </div>
  );
};
export default Loader;
