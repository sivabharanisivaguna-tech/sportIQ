import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import Button from './Button';

export const ErrorState = ({
  title = 'Failed to Load Data',
  message = 'An error occurred while communicating with the SportIQ servers.',
  onRetry,
  className = '',
}) => {
  return (
    <div className={`flex flex-col items-center justify-center p-8 text-center rounded-2xl border border-rose-500/30 bg-rose-500/5 dark:bg-rose-950/10 ${className}`}>
      <div className="p-3.5 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 mb-3 shadow-md shadow-rose-500/10">
        <AlertTriangle className="w-7 h-7" />
      </div>
      <h4 className="text-base font-bold text-rose-700 dark:text-rose-300 font-display mb-1">{title}</h4>
      <p className="text-xs text-rose-600/80 dark:text-rose-200/70 max-w-sm mb-4 leading-relaxed">{message}</p>
      {onRetry && (
        <Button onClick={onRetry} variant="secondary" size="sm" icon={RefreshCw}>
          Try Again
        </Button>
      )}
    </div>
  );
};
export default ErrorState;
