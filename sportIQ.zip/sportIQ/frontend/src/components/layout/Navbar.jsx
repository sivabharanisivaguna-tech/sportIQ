import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { adminService } from '../../services/adminService';
import {
  Activity,
  LogOut,
  User,
  Shield,
  Menu,
  Bell,
  CheckCircle2,
  Clock,
  Building,
  Users,
  ChevronRight
} from 'lucide-react';
import Badge from '../common/Badge';
import ThemeToggle from '../common/ThemeToggle';
import { getRoleBadgeColor } from '../../utils/formatters';

export const Navbar = ({ onToggleSidebar }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [notifications, setNotifications] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (user?.role === 'ADMIN') {
      const fetchNotifs = async () => {
        try {
          const data = await adminService.getNotifications();
          setNotifications(data || []);
        } catch (e) {
          console.error('Failed to load admin notifications:', e);
        }
      };
      fetchNotifs();
      const interval = setInterval(fetchNotifs, 30000); // 30s polling for admin alerts
      return () => clearInterval(interval);
    }
  }, [user?.role]);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowNotifs(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const totalNotifCount = notifications.reduce((acc, n) => acc + (n.count || 0), 0);

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-slate-950/80 px-4 sm:px-6 backdrop-blur-md transition-colors duration-200">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          aria-label="Toggle navigation menu"
          className="p-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>

        <Link to="/" className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-md shadow-cyan-500/20">
            <Activity className="h-5 w-5 text-white" />
          </div>
          <span className="font-display text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Sport<span className="text-cyan-500 dark:text-cyan-400">IQ</span>
          </span>
          {user?.role === 'ADMIN' && (
            <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 text-[10px] font-extrabold uppercase tracking-wider ml-1">
              Admin Portal
            </span>
          )}
        </Link>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        {/* Admin Notifications Bell */}
        {user?.role === 'ADMIN' && (
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setShowNotifs(!showNotifs)}
              className="relative p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
              title="Admin Alerts & Notifications"
            >
              <Bell className="w-5 h-5" />
              {totalNotifCount > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-white shadow">
                  {totalNotifCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {showNotifs && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-4 pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    Admin Notifications
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">{notifications.length} alerts</span>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
                  {notifications.length > 0 ? (
                    notifications.map((n) => (
                      <Link
                        key={n.id}
                        to={n.link}
                        onClick={() => setShowNotifs(false)}
                        className="p-3.5 flex items-start gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors block"
                      >
                        <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5">
                          {n.category === 'EVENT_SUBMISSION' ? <Clock className="w-4 h-4 text-amber-500" /> :
                           n.category === 'ORGANIZER_VERIFICATION' ? <Building className="w-4 h-4 text-emerald-500" /> :
                           <Users className="w-4 h-4 text-cyan-500" />}
                        </div>
                        <div className="flex-1 space-y-0.5 text-xs">
                          <p className="font-bold text-slate-900 dark:text-white">{n.title}</p>
                          <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">{n.message}</p>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0 self-center" />
                      </Link>
                    ))
                  ) : (
                    <div className="p-6 text-center text-xs text-slate-500">
                      No active notifications. All queues clear.
                    </div>
                  )}
                </div>

                <div className="px-4 pt-2 border-t border-slate-100 dark:border-slate-800 text-center">
                  <Link
                    to="/admin/events/verification"
                    onClick={() => setShowNotifs(false)}
                    className="text-[11px] font-bold text-cyan-600 dark:text-cyan-400 hover:underline"
                  >
                    Open Event Verification Queue →
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Quick Theme Toggle */}
        <ThemeToggle size="sm" />

        {user ? (
          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              to={user.role === 'ADMIN' ? '/admin/profile' : user.role === 'PLAYER' ? '/player/profile' : user.role === 'ORGANIZER' ? '/organizer/profile' : '#'}
              className="hidden sm:flex flex-col items-end hover:opacity-80 transition-opacity"
            >
              <span className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white">{user.name}</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">{user.email || user.phone_number}</span>
            </Link>

            <Badge variant="primary" className={getRoleBadgeColor(user.role)}>
              {user.role}
            </Badge>

            <button
              onClick={handleLogout}
              title="Sign Out"
              aria-label="Sign out of account"
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition-all cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden md:inline">Logout</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Link
              to="/login"
              className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
            >
              Sign In
            </Link>
            <Link
              to="/register"
              className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl shadow-md shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500 transition-all"
            >
              Get Started
            </Link>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
